from direct.showbase.ShowBase import ShowBase
from direct.gui.OnscreenImage import OnscreenImage
from direct.gui.DirectGui import *  
import  time
from direct.interval.MetaInterval import Sequence
from direct.interval.FunctionInterval import Func, Wait
from direct.actor import Actor
from panda3d.core import AmbientLight, DirectionalLight
from panda3d.core import LVector3
from direct.gui.OnscreenText import OnscreenText
from panda3d.core import *
loadPrcFileData('', 'win-size 700 700') 
loadPrcFileData('', 'win-size 700 700') 
class MyApp(ShowBase):

	def __init__(self):
		ShowBase.__init__(self)
		self.base = self
		self.startB = DirectButton(text="Start",
		                 scale=0.5,pos=(0,0,0), command=self.start)
		self.startB.setR(90)
		self.b1 = DirectButton(text="Tap",
		                 scale=0.3,hpr=(0,0,90),pos=(0,0,0.725), command=self.c1)

		self.b2 = DirectButton(text="Tap",
		                 scale=0.3,hpr=(0,0,90),pos=(0,0,-0.7), command=self.c2)

		self.bar = DirectWaitBar(text = "", value = 50, pos = (1,0,0),      
                     range = 100, frameColor = (1,1,1,1))  
		

		self.text = OnscreenText(text="", fg=(1, 1, 1, 1), pos=(0, 0.5, 0), shadow=(0, 0, 0, .5), scale=0.3)
		self.bar.setHpr(0,0,90)
		self.text.setHpr(0,0,90)
		self.time = 0

		self.robot1 = Actor.Actor('models/robot',
                                  {'leftPunch': 'models/robot_left_punch',
                                   'rightPunch': 'models/robot_right_punch',
                                   'headUp': 'models/robot_head_up',
                                   'headDown': 'models/robot_head_down'})

        # Actors need to be positioned and parented like normal objects
		self.robot1.setPosHprScale(13, -0.5, 10.5, 0, 0, 90, 1.25, 1.25, 1.25)
		self.robot1.reparentTo(render)
		print(int(self.base.win.getProperties().getXSize()),
			int(self.base.win.getProperties().getYSize()))
		self.robot2 = Actor.Actor('models/robot',
                                  {'leftPunch': 'models/robot_left_punch',
                                   'rightPunch': 'models/robot_right_punch',
                                   'headUp': 'models/robot_head_up',
                                   'headDown': 'models/robot_head_down'})
		self.robot1.hide()
		self.robot2.hide()
        # Actors need to be positioned and parented like normal objects
		self.robot2.setPosHprScale(13, -0.5, 5.5, 180, 0, -90, 1.25, 1.25, 1.25)
		
		
		self.robot2.setColor((.7, 0, 0, 1))

		self.robot2.reparentTo(render)
		self.robot1.punchRight = Sequence(
            self.robot1.actorInterval('rightPunch', startFrame=1, endFrame=10),

            self.robot1.actorInterval('rightPunch', startFrame=11, endFrame=32))
		self.robot2.punchRight = Sequence(
            self.robot2.actorInterval('rightPunch', startFrame=1, endFrame=10),

            self.robot2.actorInterval('rightPunch', startFrame=11, endFrame=32))


		camera.setPosHpr(18.9, -74.9999, 8.7, 0,0, 0)
		self.disableMouse()

		ambientLight = AmbientLight("ambientLight")
		ambientLight.setColor((.8, .8, .75, 1))
		directionalLight = DirectionalLight("directionalLight")
		directionalLight.setDirection(LVector3(0, 0, -2.5))
		directionalLight.setColor((0.9, 0.8, 0.9, 1))
		render.setLight(render.attachNewNode(ambientLight))
		render.setLight(render.attachNewNode(directionalLight))

		self.mainMenu()
	def timer(self,iters):
		self.time+=1
		if self.time == iters:
			self.time = 0
			return True
		#print(self.time)
	def start(self):
		self.b1.show()
		self.bar.show()
		self.b2.show()
		self.robot1.show()
		self.robot2.show()
		self.startB.hide()

	def c1(self):
		self.bar["value"] += 3
		        # Punch sequence for robot 1's right arm

		self.robot1.punchRight.start()

		if self.bar["value"] > 100:
			
			
			self.text.setText("Wins Blue")
			self.Mloop = self.taskMgr.add(self.loop, 'main loop')
		#self.l[0] = True

	def c2(self):
		self.bar["value"] -= 3
		self.robot2.punchRight.start()
		if self.bar["value"] < 0:
			
			self.text.setText("Wins Red")
			
			self.Mloop = self.taskMgr.add(self.loop, 'main loop')
		#self.l[1] = True
	def loop(self,task):
		t = self.timer(150)

		if t == True:

			self.mainMenu()
			self.Mloop.remove()
			self.text.hide()
		return task.cont
	def mainMenu(self):
		
		self.bar["value"] > 50
		self.b1.hide()
		self.bar.hide()
		self.b2.hide()
		self.robot1.hide()
		self.robot2.hide()
		self.startB.show()
app = MyApp()
app.run()